package lab03;

public class Task9 {

    /**
     * Обчислює функцію:
     * x(t, n) = Σ (t / i), i = 1..n
     * (1 ≤ t ≤ 3.5, 1 ≤ n ≤ 4.6)
     */
    public static double calculate(double t, double n) {
        if (t < 1 || t > 3.5 || n < 1 || n > 4.6) {
            throw new IllegalArgumentException("t ∈ [1;3.5], n ∈ [1;4.6]");
        }

        int nInt = (int) Math.floor(n);
        double sum = 0;
        for (int i = 1; i <= nInt; i++) {
            sum += t / i;
        }
        return sum;
    }

    public static void main(String[] args) {
        test(1, 4);
        test(2.5, 4.5);
        test(3.5, 2);
        test(0.5, 4);
        test(4, 5);
    }

    private static void test(double t, double n) {
        System.out.print("t:" + t + " n:" + n + " result: ");
        try {
            System.out.println(calculate(t, n));
        } catch (IllegalArgumentException e) {
            System.out.println("EXCEPTION! " + e.getMessage());
        }
    }
}
