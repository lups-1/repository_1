package lab03;

public class Task11 {

    /**
     * Обчислює нескінченну суму:
     * S = Σ (1 / i^2), з точністю ε > 0
     */
    public static double calculate(double epsilon) {
        if (epsilon <= 0) {
            throw new IllegalArgumentException("ε має бути > 0");
        }

        double sum = 0;
        int i = 1;
        while (true) {
            double term = 1.0 / (i * i);
            if (Math.abs(term) < epsilon) break;
            sum += term;
            i++;
        }
        return sum;
    }

    public static void main(String[] args) {
        test(0.1);
        test(0.01);
        test(0.0001);
        test(-0.5);
    }

    private static void test(double epsilon) {
        System.out.print("ε:" + epsilon + " result: ");
        try {
            System.out.println(calculate(epsilon));
        } catch (IllegalArgumentException e) {
            System.out.println("EXCEPTION! " + e.getMessage());
        }
    }
}
