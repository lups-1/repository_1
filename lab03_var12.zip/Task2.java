package lab03;

public class Task2 {

    /**
     * Обчислює суму ряду:
     * S = Σ ln(-i) * cos(cuberoot(1 / i^2)), i = 1..k
     * (2 < k ≤ 25)
     */
    public static double calculate(int k) {
        if (k <= 2 || k > 25) {
            throw new IllegalArgumentException("k має бути в межах (2; 25]");
        }

        double sum = 0;
        for (int i = 1; i <= k; i++) {
            double value = Math.log(-i) * Math.cos(Math.cbrt(1.0 / (i * i)));
            sum += value;
        }
        return sum;
    }

    public static void main(String[] args) {
        test(3);
        test(10);
        test(25);
        test(1);
        test(30);
    }

    private static void test(int k) {
        System.out.print("k:" + k + " result: ");
        try {
            System.out.println(calculate(k));
        } catch (IllegalArgumentException e) {
            System.out.println("EXCEPTION! " + e.getMessage());
        }
    }
}
